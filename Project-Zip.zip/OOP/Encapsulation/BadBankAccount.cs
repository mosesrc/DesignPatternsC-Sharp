﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternsTutorial.OOP.Encapsulation
{
    class BadBankAccount
    {
        public decimal balance;
    }
}
