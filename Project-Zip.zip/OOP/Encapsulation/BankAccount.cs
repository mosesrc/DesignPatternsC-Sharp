﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternsTutorial.OOP.Encapsulation
{
    class BankAccount
    {
        private decimal _balance;

        public decimal Balance { get { return _balance; } }

        public BankAccount(decimal balance)
        {
            Deposit(balance);
        }
        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Deposit amount must be positive.");
            }

            this._balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Withdraw amount must be positive.");
            }

            if (amount > _balance)
            {
                throw new InvalidOperationException("Insufficient funds.");
            }

            this._balance -= amount;    
        }
    }
}
