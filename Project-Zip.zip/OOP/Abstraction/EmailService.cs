﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternsTutorial.OOP.Abstraction
{
    class EmailService
    {
        public void SendEmail()
        {
            Connect();
            Authenticate();
            // Code to send email
            Console.WriteLine("Email sent.");
            Disconnect();
        }

        private void Connect()
        {
            // Code to connect to email server
            Console.WriteLine("Connected to email server.");
        }

        private void Authenticate()
        {
            // Code to authenticate email service
            Console.WriteLine("Email service authenticated.");
        }

        private void Disconnect()
        {
            // Code to disconnect from email server
            Console.WriteLine("Disconnected from email server.");
        }
    }
}
