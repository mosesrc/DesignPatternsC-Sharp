﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternsTutorial.OOP.Composition
{
    class Seats
    {
        public void Sit()
        {
            Console.WriteLine("Sitting on the seats.");
        }
    }
}
