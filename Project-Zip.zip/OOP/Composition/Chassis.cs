﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternsTutorial.OOP.Composition
{
    class Chassis
    {
        public void Support()
        {
            Console.WriteLine("Chassis is supporting the car.");
        }
    }
}
