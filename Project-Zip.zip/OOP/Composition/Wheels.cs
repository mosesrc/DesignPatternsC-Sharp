﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternsTutorial.OOP.Composition
{
    class Wheels
    {
        public void Rotate()
        {
            Console.WriteLine("Wheels are rotating.");
        }
    }
}
