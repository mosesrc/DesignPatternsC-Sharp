﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternsTutorial.OOP.Coupling
{
    class EmailSender : INotificationService
    {

        public void SendNotification(string message)
        {
            // Code to send email
            Console.WriteLine("Sending Email: " + message);
        }
    }
}
